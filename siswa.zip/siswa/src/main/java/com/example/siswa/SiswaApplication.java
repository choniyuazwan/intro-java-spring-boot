package com.example.siswa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiswaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiswaApplication.class, args);
	}

}
